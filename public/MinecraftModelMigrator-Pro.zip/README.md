# Minecraft Model Migrator Pro — Converter Suite

> **SRParasites Mod: MC 1.12.2 → MC 1.20.1 GeckoLib Model & Animation Converter**
>
> A complete, mathematically rigorous pipeline for converting Minecraft 1.12.2 Java entity models
> (ModelBase / ModelRenderer) to GeckoLib 1.20.1 format (.geo.json + .animation.json),
> with Blockbench (.bbmodel) intermediate support for visual editing.

---

## 1. Architecture Overview

```
                          ┌─────────────────────────────────────┐
                          │   MC 1.12.2 Java Source Files       │
                          │   (ModelBase + ModelRenderer)       │
                          └──────────┬──────────────────────────┘
                                     │
                          ┌──────────▼──────────────────────────┐
                          │       model_converter.py            │
                          │   (Java → .geo.json conversion)     │
                          │   Uses core_math.py M_MODEL matrix  │
                          └──────────┬──────────────────────────┘
                                     │
                    ┌────────────────┼────────────────────┐
                    │                │                     │
          ┌─────────▼──────┐  ┌─────▼──────────┐  ┌─────▼──────────────┐
          │  .geo.json     │  │  .bbmodel       │  │  .animation.json   │
          │  (GeckoLib     │  │  (Blockbench    │  │  (GeckoLib anim    │
          │   geometry)    │  │   project)      │  │   keyframes)       │
          └────────────────┘  └─────┬──────────┘  └────────────────────┘
                                    │
                          ┌─────────▼──────────────────────────┐
                          │  bbmodel_animation_converter_v18   │
                          │  (.bbmodel → .animation.json)      │
                          └────────────────────────────────────┘
```

### Two Conversion Paths

1. **Direct Path (Recommended for Production):**
   `Java → model_converter.py → .geo.json + batch_geo_export.py → GeckoLib .geo.json + PNG`

2. **Blockbench Path (For Visual Editing):**
   `Java → model_converter.py → .geo.json → bbmodel_generator.py → .bbmodel → bbmodel_to_geo.py → GeckoLib .geo.json`
   `+ .bbmodel → bbmodel_animation_converter_v18 → .animation.json`

---

## 2. Core Pipeline Components

### 2.1 Coordinate System Transformation — `core_math.py`

**THE FOUNDATION — DO NOT MODIFY**

Implements the mathematically proven transformation from MC 1.12.2 (Y-down, Right-Hand, Z into screen)
to GeckoLib 1.20.1 (Y-up, Left-Hand, Z out of screen).

**Transformation Matrix:**
```
M_MODEL = diag(1, -1, -1)    // Flips Y and Z axes
M_MODEL⁻¹ = M_MODEL          // Self-inverse
```

| Function | Formula | Usage |
|---|---|---|
| `convert_model_pos(x, y, z)` | `(x, -y, -z)` | Bone pivot positions |
| `convert_model_rot(rx, ry, rz)` | `(rx, -ry, -rz)` | Single-axis rotations |
| `convert_model_rotation_order(rx, ry, rz)` | Matrix-based via similarity transform | Multi-axis rotations |
| `convert_model_cube_origin(ox, oy, oz, w, h, d)` | `(ox, -(oy+h), -(oz+d))` | Cube minimum corner |
| `convert_model_cube_size(w, h, d)` | `(w, h, d)` | Dimensions preserved |

**Also provides pure RH→LH transforms:**
- `M = diag(1, 1, -1)` — Only Z-flip (no Y-flip)
- `convert_pos(x, y, z) = (x, y, -z)`
- `convert_rot(rx, ry, rz) = (-rx, ry, -rz)`

### 2.2 Model Converter — `model_converter.py`

Converts MC 1.12.2 `ModelBase` Java source to GeckoLib `.geo.json`.

**Features:**
- AST-based Java parsing (via `javalang`) + text-based SRG name resolution
- SRG obfuscated method/field name mapping (`func_78793_a` → `setRotationPoint`, etc.)
- Automatic bone hierarchy from `addChild()` calls
- Absolute pivot computation + relative pivot adjustment for root offset
- Cube origin/size/UV conversion using `core_math.py`
- Mirror flag propagation
- Cycle detection in bone hierarchy

**Output format:**
```json
{
  "format_version": "1.12.0",
  "model": {
    "identifier": "model.kirin",
    "texture_width": 256,
    "texture_height": 256,
    "bones": [
      { "name": "root", "pivot": [0, 24, 0] },
      { "name": "body", "parent": "root", "pivot": [...], "cubes": [...] }
    ]
  }
}
```

### 2.3 BBModel Generator — `bbmodel_generator.py`

Generates Blockbench `.bbmodel` project files from `.geo.json` output.

**Key transformations:**
- Absolute pivot computation (Y_OFFSET=24.0 correction for root's children)
- Element from/to in ABSOLUTE world-space coordinates
- North↔South UV face swap (RH→LH Z-flip correction)
- West↔East UV swap for mirrored cubes (geometric X-mirror correction)
- Geometric X-mirror for `mirror=true` cubes (negating from/to X around pivot)
- Rotation conversion via scipy (extrinsic XYZ → intrinsic xyz)
- Root bone 180° Y rotation (compensates for coordinate flip)
- Embedded texture PNG as base64 data URI
- Animation keyframe conversion with per-axis carry-forward merging

### 2.4 BBModel → Geo Converter — `bbmodel_to_geo.py`

Converts `.bbmodel` files back to Bedrock/GeckoLib `.geo.json` + extracts textures.

**Key transformations:**
- X-mirror on all bone pivots and cube origins (accounts for root's 180° Y rotation)
- Rotation sign flip: `[-rx, -ry, rz]`
- UV format conversion: side faces `uv=[u1,v1], uv_size=[w,h]`; up/down faces `uv=[u2,v2], uv_size=[-w,-h]`

### 2.5 Animation Converter v18 — `bbmodel_animation_converter_v18.py`

**The most complex component — 18+ major iterations of refinement.**

Converts `.bbmodel` animation keyframes to GeckoLib `.animation.json` with:

**Continuity Enforcement (C0/C1/C2):**
- **C0**: Position continuity — last keyframe = first keyframe (guaranteed 100%)
- **C1**: Velocity continuity — 7th-degree polynomial (septic) global correction
- **C2**: Acceleration continuity — quintic Hermite transition zone
- Multi-pass iterative C1 refinement (up to 3 passes)
- Adaptive transition zone expansion for high-C1-error channels

**Walk Cycle Intelligence:**
- Half-cycle detection & mirroring (sparse keyframe → full cycle)
- Full walk cycle reconstruction with 240Hz resampling
- Leg-pair detection (left/right naming patterns)
- Body sway phase correction
- Walk-aware DP simplification (minimum 12-16 keyframes per channel)
- Duration extension with keyframe replication
- Periodic extrapolation for smooth cycle boundaries

**Smart Deduplication:**
- Case-insensitive animation name merging
- Content-hash (SHA-256) dedup
- Cross-model idle consolidation
- Exact-duplicate detection (idle/evolved/attack with identical data)
- Protected category dedup (attack≠idle, evolved≠sleep)

**Animation Quality:**
- Autocorrelation + FFT spectral period detection
- Phase-coherent loop duration optimization
- Bounce-bridge with cosine easing for velocity reversals
- Periodic channel loop smoothing
- Bone chain phase coherence (tentacles, hair)
- Smart truncation of static tails
- Empty/truly-static animation elimination
- Naturalness scoring (curvature smoothness metric)

---

## 3. Batch Processing Scripts

### `batch_convert_all.py` — Full Pipeline
End-to-end processing: `.bbmodel` → `.geo.json` + `.animation.json` + `.png` + ZIP package

**Steps:**
1. `bbmodel_to_geo.py` converts geometry + extracts texture
2. `bbmodel_animation_converter_v18` converts animations
3. Post-processing: model grounding (Y-shift), UV bounds fixing
4. ZIP packaging organized by creature category

### `batch_geo_export.py` — Direct Java → GeckoLib
Skips `.bbmodel` intermediate — Java source → `.geo.json` + `.png` directly

### `batch_convert.py` — Model + Texture Batch
Java source → `.geo.json` + `.png` with texture name mapping

### `batch_animation_convert.py` — Universal Animation Batch
Callback-based animation generation with creature-specific eval functions

---

## 4. Supporting Components

### Parsers (`parsers/`)
- **base_parser.py**: Abstract base class for plugin architecture
- **java_source_parser.py**: Java AST parsing for model data
- **bytecode_parser.py**: `.class` file bytecode parsing for animation data

### Enhancements (`enhancements/layer1_deep/`)
- **animation_reference_validator.py**: Cross-reference animation bone names with model
- **particle_detector.py**: Detect particle emission keyframes
- **animation_naming_manager.py**: Standardize animation names
- **overlay_detector.py**: Detect overlay rendering layers
- **firstperson_detector.py**: First-person arm animation detection
- **sound_keyframe_filler.py**: Auto-fill sound event keyframes

### Creature-Specific Generators
- **kirin_animation_generator.py**: Kirin (quadruped) eval functions
- **heblu_animation_generator.py**: Heblu (flying) eval functions
- **iki_animation_generator.py**: Iki eval functions
- **venkrolSIV_animation_generator.py**: Venkrol SIV eval functions

### Utility Modules
- **easing_fitter.py**: Fit animation curves to easing functions
- **swing_analyzer.py**: Analyze swing physics for limb animations
- **render_effect_parser.py**: Parse render effect parameters
- **dynamic_visibility_detector.py**: Detect bone visibility animations
- **keyframe_event_marker.py**: Mark events (sound/particle) at keyframes
- **quality_audit_system.py**: Audit animation quality metrics
- **verifier.py**: Verify output correctness

### Templates (`templates/`)
Jinja2 templates for output generation:
- `geo_model.game.json.j2` — GeckoLib game format
- `geo_model.blockbench.json.j2` — Blockbench preview format
- `java_model.java.j2` — Re-generate Java source
- `java_animation.java.j2` — Java animation code
- `java_controller.java.j2` — Java controller code
- `animation.json.j2` — GeckoLib animation format
- `utility_class.java.j2` — Utility class template

---

## 5. Technology Stack

| Component | Technology |
|---|---|
| Language | Python 3.8+ |
| Math | NumPy (matrix operations, FFT autocorrelation) |
| Rotation | SciPy `spatial.transform.Rotation` (Euler conversion) |
| Java Parsing | `javalang` (AST), regex (SRG name resolution) |
| Templates | Jinja2 |
| Output Formats | JSON (.geo.json, .animation.json, .bbmodel) |
| Textures | PNG (base64 embedded in .bbmodel) |
| Dedup | SHA-256 content hashing |

---

## 6. Coordinate System Reference

### MC 1.12.2 (Source)
- **System**: Right-Hand, Y-DOWN
- **Origin**: Top of entity hitbox
- **X**: Right
- **Y**: Downward (0 at top, positive toward feet)
- **Z**: Into screen (right-hand rule)

### GeckoLib 1.20.1 (Target)
- **System**: Left-Hand, Y-UP
- **Origin**: Entity feet (ground plane)
- **X**: Right
- **Y**: Upward (0 at feet, positive toward head)
- **Z**: Out of screen (left-hand rule)

### Blockbench .bbmodel
- **System**: Left-Hand, Y-UP (same as GeckoLib)
- **Key difference**: Element positions and bone pivots are ABSOLUTE world-space
- **Root bone**: Has 180° Y rotation to compensate for Z-flip

---

## 7. Current Status & Known Issues

### ✅ Working
- Model geometry conversion (Java → geo.json)
- Coordinate system transformation (M_MODEL)
- UV mapping and face swap corrections
- Blockbench .bbmodel generation and reading
- Animation keyframe extraction from .bbmodel
- C0/C1/C2 continuity enforcement
- Walk cycle detection and reconstruction
- Batch processing pipeline
- Model grounding (Y-shift to ground plane)
- Texture extraction and embedding

### ⚠️ Known Issues
1. **Model block scattering**: When using the bbmodel_generator.py path (geo.json → .bbmodel → geo.json),
   absolute coordinate handling may cause blocks to appear scattered/split. The direct path (Java → geo.json) works correctly.

2. **Model floating**: Some models appear to float above the ground plane despite Y-grounding logic.

3. **Animation artifacts**: Despite 18 iterations of improvement:
   - Stuttering on some walk cycles
   - Legs not moving on certain entities
   - Body sway issues
   - Flashing at loop boundaries (reduced but not eliminated)

4. **Heblu wing tips**: The outermost wing bones (`skin_2_c0`, `skin_5_c0`) have incorrect
   rotation/position — multi-axis rotation accumulation issue through bone chain.

---

## 8. File Manifest

### Core Converter Files
| File | Purpose |
|---|---|
| `converter/core_math.py` | Coordinate transformation (DO NOT MODIFY) |
| `converter/model_converter.py` | Java → geo.json model converter |
| `converter/bbmodel_generator.py` | geo.json → .bbmodel generator |
| `converter/bbmodel_to_geo.py` | .bbmodel → geo.json converter |
| `converter/bbmodel_animation_converter_v18.py` | Animation converter (v18, latest) |
| `converter/bbmodel_animation_converter.py` | Animation converter (base) |
| `converter/animation_converter.py` | Animation converter (legacy) |
| `converter/universal_animation_converter.py` | Universal animation converter |

### Batch Processing
| File | Purpose |
|---|---|
| `converter/batch_convert_all.py` | Full pipeline (geo + anim + tex + ZIP) |
| `converter/batch_convert.py` | Model + texture batch conversion |
| `converter/batch_animation_convert.py` | Universal animation batch converter |
| `converter/batch_geo_export.py` | Direct Java → geo.json + PNG exporter |
| `converter/full_reconvert.py` | Full re-conversion script |
| `converter/reconvert_and_texture.py` | Re-convert with texture mapping |
| `converter/reconvert_remaining.py` | Re-convert remaining models |
| `converter/simple_batch.py` | Simple batch processing |

### Creature Runners & Generators
| File | Purpose |
|---|---|
| `converter/run_heblu.py` | Heblu entity conversion runner |
| `converter/run_kirin.py` | Kirin entity conversion runner |
| `converter/kirin_animation_generator.py` | Kirin animation eval functions |
| `converter/heblu_animation_generator.py` | Heblu animation eval functions |
| `converter/iki_animation_generator.py` | Iki animation eval functions |
| `converter/venkrolSIV_animation_generator.py` | Venkrol SIV animation eval functions |
| `converter/convert_abomination.py` | Special abomination converter |

### Utilities
| File | Purpose |
|---|---|
| `converter/easing_fitter.py` | Easing curve fitting |
| `converter/swing_analyzer.py` | Swing physics analysis |
| `converter/render_effect_parser.py` | Render effect parsing |
| `converter/dynamic_visibility_detector.py` | Dynamic visibility detection |
| `converter/keyframe_event_marker.py` | Keyframe event marking |
| `converter/quality_audit_system.py` | Quality auditing system |
| `converter/verifier.py` | Output verification |
| `converter/fix_y_negative_models.py` | Fix Y-negative models |
| `converter/animation_extractor.py` | Animation extraction utility |
| `converter/animation_layer_separator.py` | Animation layer separation |
| `converter/cli.py` | CLI entry point |
| `converter/setup.py` | Package setup |
| `converter/package_mod_dev.py` | Mod dev package builder |

### Verification
| File | Purpose |
|---|---|
| `converter/verify_fixes.py` | Fix verification (v1) |
| `converter/verify_fixes_v2.py` | Fix verification (v2) |

### Parsers (`converter/parsers/`)
| File | Purpose |
|---|---|
| `__init__.py` | Package init |
| `base_parser.py` | Abstract parser base class |
| `java_source_parser.py` | Java source AST parser |
| `bytecode_parser.py` | Bytecode parser |

### Enhancements (`converter/enhancements/layer1_deep/`)
| File | Purpose |
|---|---|
| `__init__.py` | Package init |
| `animation_reference_validator.py` | Animation reference validator |
| `particle_detector.py` | Particle keyframe detector |
| `animation_naming_manager.py` | Animation name manager |
| `overlay_detector.py` | Overlay layer detector |
| `firstperson_detector.py` | First-person detector |
| `sound_keyframe_filler.py` | Sound keyframe filler |

### Templates (`converter/templates/`)
| File | Purpose |
|---|---|
| `geo_model.game.json.j2` | GeckoLib game geo template |
| `geo_model.blockbench.json.j2` | Blockbench geo template |
| `java_model.java.j2` | Java model template |
| `java_animation.java.j2` | Java animation template |
| `java_controller.java.j2` | Java controller template |
| `animation.json.j2` | GeckoLib animation template |
| `utility_class.java.j2` | Utility class template |

### Reference Java Sources (`decompiled/`)
| File | Purpose |
|---|---|
| `com/.../ModelSRP.java` | Base SRP model class |
| `com/.../ModelHeblu.java` | Heblu model reference |
| `com/.../ModelKirin.java` | Kirin model reference |
| `com/.../RenderHeblu.java` | Heblu renderer reference |
| `com/.../RenderKirin.java` | Kirin renderer reference |
| `com/.../EntityHeblu.java` | Heblu entity reference |
| `com/.../EntityKirin.java` | Kirin entity reference |

### Documentation (`converter/`)
| File | Purpose |
|---|---|
| `HANDOFF_DOC.md` | Critical debugging experience & handoff |
| `TECHNICAL_DOC.md` | Technical documentation |
| `TECHNICAL_GUIDE.md` | Technical guide |

---

## 9. Quick Start

```bash
# Full pipeline (recommended)
cd converter
python batch_convert_all.py

# Single model conversion
python cli.py convert ModelKirin.java -o output/ --identifier model.kirin

# Direct Java → GeckoLib export
python batch_geo_export.py --source /path/to/src/ --output /path/to/output/ --textures /path/to/textures/

# Animation conversion from .bbmodel
python bbmodel_animation_converter_v18.py --input model.bbmodel --output model.animation.json
```

---

## 10. Scale

- **154 .bbmodel files** across 13 creature categories
- **295 animations** converted
- **13 categories**: infected, crude, primitive, pure, adapted, focused, inborn, deterrent, ancient, awakened, feral, hijacked, misc + abomination, derived, projectile

---

*Generated by Minecraft Model Migrator Pro — Architecture Documentation*
*Last Updated: 2025-03-05*
